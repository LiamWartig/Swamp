import java.util.Scanner;
public class Play {
public static void play(Position treasure,Position player) {
	Scanner sc = new Scanner(System.in);
	int nesw;
	double dis = Distance.distance(treasure,player);
	while (dis!=0) {	
		System.out.println("you are " + dis + " away from treasure");
		System.out.println("type direction to move");
		nesw = sc.nextInt();
		if(nesw==1) {
			player.setY(1);
			System.out.println("moved north");}
		if(nesw==2) {
			player.setX(1);
			System.out.println("moved east");}
		if(nesw==3) {
			player.setY(-1);
			System.out.println("moved south");}
		if(nesw==4) {
			player.setX(-1);
			System.out.println("moved west");}
	dis = Distance.distance(treasure,player);}
	sc.close();}}