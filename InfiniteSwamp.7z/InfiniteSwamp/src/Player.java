public class Player extends Position{
	private int pX;
	private int pY;
	public Player(int pX, int pY) {
		this.pX = pX;
		this.pY = pY;}
	public int getX() {
		return pX;}
	public int getY() {
		return pY;}
	public void setY(int i) {
		this.pY += i;
		if(this.pY>10) {
			this.pY=1;}
		if(this.pY<1) {
			this.pY=10;}}
	public void setX(int i) {
		this.pX += i;
		if(this.pX>10) {
			this.pX=1;}
		if(this.pX<1) {
			this.pX=10;}}}