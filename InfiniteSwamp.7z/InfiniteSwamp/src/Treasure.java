public class Treasure extends Position{
	private int tX;
	private int tY;
	public Treasure(int posX, int posY) {
		this.tX = posX;
		this.tY = posY;}
	public int getX() {
		return tX;}
	public int getY() {
		return tY;}
	public void setY(int tY) {
		this.tY = tY ;}
	public void setX(int tY) {
		this.tX = tY;}}