public abstract class Position {
	public abstract int getX();
	public abstract int getY();
	public abstract void setX(int i);
	public abstract void setY(int i);}