import java.util.Scanner;
public class App {
	public static void main(String[] args){
		final int treX =(int)(Math.random()*10)+1;
		final int treY =(int)(Math.random()*10)+1;
		Treasure treasure = new Treasure(treX,treY);
		int plaX =(int)(Math.random()*10)+1;
		int plaY =(int)(Math.random()*10)+1;
		if(plaX==treX) {
			plaX =(int)(Math.random()*10)+1;}
		Player player = new Player (plaX,plaY);
		System.out.println("type number for movement direction \n up: 1 \n right:2 \n down: 3 \n left: 4 ");
		System.out.println("do you have a name? (yes/no)");
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		if(s.equals("yes")) {
			System.out.println("what is it");
			String name = sc.next();
			System.out.println("ok, " + Name.name(name));}
		if(s.equals("no")) {
			System.out.println("ok, ya " + Name.name());}
		Play.play(treasure,player);
		System.out.println("you found treasure");
		sc.close();}}