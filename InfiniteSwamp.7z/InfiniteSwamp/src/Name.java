public class Name {
	public static String name() {
		return "Dingus";}
	public static String name(String a) {
		return a;}}