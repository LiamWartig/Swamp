public abstract class Distance {
	public static double distance(Position t, Position p) {
		int aX = t.getX();
		int bX = p.getX();
		int aY = t.getY();
		int bY = p.getY();
		double delX = (aX-bX);
		double delY = (aY-bY);
		double d = Math.pow(((Math.pow(delX,2))+(Math.pow(delY,2))),0.5);
		return d;}}